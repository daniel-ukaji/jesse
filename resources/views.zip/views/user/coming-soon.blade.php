<x-app-layout>
    <div class="text-center">
        <p class="fs-1 text-secondary my-5">
            <i class="bi bi-emoji-smile"></i>
        </p>
        <p class="fs-1 text-secondary text-center my-5">
            Coming soon
        </p>

        <a href="/">
            <button class="btn btn-secondary">Home</button>
        </a>
    </div>
</x-app-layout>
